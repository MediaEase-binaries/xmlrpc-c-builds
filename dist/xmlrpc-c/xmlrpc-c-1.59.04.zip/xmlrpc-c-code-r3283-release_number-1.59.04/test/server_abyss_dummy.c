#include <stdio.h>

#include "server_abyss.h"



void 
test_server_abyss(void) {

    printf("Running dummy Abyss XML-RPC server test\n");

    printf("\n");
    printf("Abyss XML-RPC server tests done.\n");
}
