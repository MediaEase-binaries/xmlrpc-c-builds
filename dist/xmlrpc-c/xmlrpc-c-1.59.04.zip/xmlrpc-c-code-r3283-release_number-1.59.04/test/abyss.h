void
test_abyss(void);
